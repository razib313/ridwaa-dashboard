const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const employees = [
  { id: 1, name: "Ahmed Khan", role: "Supervisor" },
  { id: 2, name: "Salim Pasha", role: "Plumber" },
];

app.get("/api/employees", (req, res) => res.json(employees));

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
